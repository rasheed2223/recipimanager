"use client"

import { useState } from "react"
import RecipeList from "@/components/recipe-list"
import RecipeDetails from "@/components/recipe-details"
import RecipeSubmissionForm from "@/components/recipe-submission-form"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { Recipe } from "@/types/recipe"
import { fetchRandomRecipe } from "@/lib/api"
import { ChefHat } from "lucide-react"

export default function Home() {
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null)
  const [activeTab, setActiveTab] = useState("browse")
  const [isLoading, setIsLoading] = useState(false)

  const handleRecipeSelect = (recipe: Recipe) => {
    setSelectedRecipe(recipe)
    setActiveTab("details")
  }

  const handleSurpriseMe = async () => {
    setIsLoading(true)
    try {
      const randomRecipe = await fetchRandomRecipe()
      setSelectedRecipe(randomRecipe)
      setActiveTab("details")
    } catch (error) {
      console.error("Error fetching random recipe:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <main className="min-h-screen py-8 px-4">
      <div className="container mx-auto">
        <div className="page-header">
          <div className="flex items-center gap-3">
            <ChefHat className="h-8 w-8" />
            <h1 className="text-3xl font-bold">Recipe Manager</h1>
          </div>
          <p className="text-white/80 mt-2 max-w-md">
            Discover, organize, and create delicious recipes for any occasion
          </p>

          <div className="mt-6">
            <Button
              onClick={handleSurpriseMe}
              disabled={isLoading}
              className="bg-white text-recipe-spice hover:bg-white/90"
            >
              {isLoading ? "Loading..." : "Surprise Me with a Random Recipe!"}
            </Button>
          </div>
        </div>

        <div className="tabs-container">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8 p-1 bg-muted">
              <TabsTrigger value="browse" className={`tab-button ${activeTab === "browse" ? "tab-button-active" : ""}`}>
                Browse Recipes
              </TabsTrigger>
              <TabsTrigger
                value="details"
                disabled={!selectedRecipe}
                className={`tab-button ${activeTab === "details" ? "tab-button-active" : ""}`}
              >
                Recipe Details
              </TabsTrigger>
              <TabsTrigger value="create" className={`tab-button ${activeTab === "create" ? "tab-button-active" : ""}`}>
                Create Recipe
              </TabsTrigger>
            </TabsList>

            <TabsContent value="browse">
              <RecipeList onRecipeSelect={handleRecipeSelect} />
            </TabsContent>

            <TabsContent value="details">{selectedRecipe && <RecipeDetails recipe={selectedRecipe} />}</TabsContent>

            <TabsContent value="create">
              <RecipeSubmissionForm onSuccess={() => setActiveTab("browse")} />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </main>
  )
}

