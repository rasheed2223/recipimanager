"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { createRecipe } from "@/lib/api"
import type { Recipe } from "@/types/recipe"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { X, Type, Clock, ListOrdered, List } from "lucide-react"

interface RecipeSubmissionFormProps {
  onSuccess: () => void
}

const recipeSchema = z.object({
  title: z.string().min(3, { message: "Title must be at least 3 characters" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
  category: z.string().min(1, { message: "Category is required" }),
  cookingTime: z.coerce.number().min(1, { message: "Cooking time must be at least 1 minute" }),
  servings: z.coerce.number().min(1, { message: "Servings must be at least 1" }),
  ingredientInput: z.string().optional(),
  instructionInput: z.string().optional(),
})

export default function RecipeSubmissionForm({ onSuccess }: RecipeSubmissionFormProps) {
  const [ingredients, setIngredients] = useState<string[]>([])
  const [instructions, setInstructions] = useState<string[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)

  const form = useForm<z.infer<typeof recipeSchema>>({
    resolver: zodResolver(recipeSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "",
      cookingTime: 30,
      servings: 4,
      ingredientInput: "",
      instructionInput: "",
    },
  })

  const addIngredient = () => {
    const ingredient = form.getValues("ingredientInput")
    if (ingredient && ingredient.trim()) {
      setIngredients([...ingredients, ingredient.trim()])
      form.setValue("ingredientInput", "")
    }
  }

  const removeIngredient = (index: number) => {
    setIngredients(ingredients.filter((_, i) => i !== index))
  }

  const addInstruction = () => {
    const instruction = form.getValues("instructionInput")
    if (instruction && instruction.trim()) {
      setInstructions([...instructions, instruction.trim()])
      form.setValue("instructionInput", "")
    }
  }

  const removeInstruction = (index: number) => {
    setInstructions(instructions.filter((_, i) => i !== index))
  }

  const onSubmit = async (values: z.infer<typeof recipeSchema>) => {
    if (ingredients.length === 0) {
      form.setError("ingredientInput", {
        type: "manual",
        message: "At least one ingredient is required",
      })
      return
    }

    if (instructions.length === 0) {
      form.setError("instructionInput", {
        type: "manual",
        message: "At least one instruction is required",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const newRecipe: Omit<Recipe, "id"> = {
        title: values.title,
        description: values.description,
        category: values.category,
        cookingTime: values.cookingTime,
        servings: values.servings,
        ingredients,
        instructions,
      }

      await createRecipe(newRecipe)
      form.reset()
      setIngredients([])
      setInstructions([])
      onSuccess()
    } catch (error) {
      console.error("Error creating recipe:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card className="recipe-form-container">
      <CardHeader className="bg-recipe-butter rounded-t-lg">
        <CardTitle>Create New Recipe</CardTitle>
        <CardDescription>Fill in the details to add a new recipe to your collection</CardDescription>
      </CardHeader>
      <CardContent className="p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="form-section">
              <h3 className="form-section-title">
                <Type className="h-5 w-5" />
                Basic Information
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Recipe Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Delicious Pasta" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <FormControl>
                        <Input placeholder="Italian, Dessert, etc." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="mt-4">
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="A brief description of your recipe"
                          className="min-h-[80px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <div className="form-section">
              <h3 className="form-section-title">
                <Clock className="h-5 w-5" />
                Cooking Details
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="cookingTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Cooking Time (minutes)</FormLabel>
                      <FormControl>
                        <Input type="number" min="1" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="servings"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Servings</FormLabel>
                      <FormControl>
                        <Input type="number" min="1" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <div className="form-section">
              <h3 className="form-section-title">
                <List className="h-5 w-5" />
                Ingredients
              </h3>
              <FormField
                control={form.control}
                name="ingredientInput"
                render={({ field }) => (
                  <FormItem>
                    <div className="flex gap-2">
                      <FormControl>
                        <Input
                          placeholder="Add an ingredient"
                          {...field}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              e.preventDefault()
                              addIngredient()
                            }
                          }}
                        />
                      </FormControl>
                      <Button type="button" onClick={addIngredient} className="bg-recipe-herb hover:bg-recipe-herb/90">
                        Add
                      </Button>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {ingredients.length > 0 && (
                <div className="ingredient-list mt-4">
                  <ul className="space-y-1">
                    {ingredients.map((ingredient, index) => (
                      <li key={index} className="flex items-center justify-between bg-white p-2 rounded-md shadow-sm">
                        <span>{ingredient}</span>
                        <Button type="button" variant="ghost" size="sm" onClick={() => removeIngredient(index)}>
                          <X className="h-4 w-4" />
                        </Button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="form-section">
              <h3 className="form-section-title">
                <ListOrdered className="h-5 w-5" />
                Instructions
              </h3>
              <FormField
                control={form.control}
                name="instructionInput"
                render={({ field }) => (
                  <FormItem>
                    <div className="flex gap-2">
                      <FormControl>
                        <Textarea placeholder="Add a step" className="min-h-[80px]" {...field} />
                      </FormControl>
                      <Button
                        type="button"
                        onClick={addInstruction}
                        className="self-start bg-recipe-herb hover:bg-recipe-herb/90"
                      >
                        Add
                      </Button>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {instructions.length > 0 && (
                <div className="instruction-list-container mt-4">
                  <ol className="instruction-list">
                    {instructions.map((instruction, index) => (
                      <li
                        key={index}
                        className="flex items-start justify-between bg-white p-3 rounded-md shadow-sm mb-3"
                      >
                        <span className="flex-1">{instruction}</span>
                        <Button type="button" variant="ghost" size="sm" onClick={() => removeInstruction(index)}>
                          <X className="h-4 w-4" />
                        </Button>
                      </li>
                    ))}
                  </ol>
                </div>
              )}
            </div>

            <Button type="submit" className="w-full bg-recipe-spice hover:bg-recipe-spice/90" disabled={isSubmitting}>
              {isSubmitting ? "Creating..." : "Create Recipe"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  )
}

