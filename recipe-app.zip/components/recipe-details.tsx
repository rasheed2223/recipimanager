import { Card, CardContent, CardTitle } from "@/components/ui/card"
import type { Recipe } from "@/types/recipe"
import { Clock, Users, ChefHat, Utensils } from "lucide-react"

interface RecipeDetailsProps {
  recipe: Recipe
}

export default function RecipeDetails({ recipe }: RecipeDetailsProps) {
  return (
    <Card className="w-full overflow-hidden">
      <div className="recipe-details-header">
        <CardTitle className="text-3xl text-recipe-spice">{recipe.title}</CardTitle>
        <span className="category-tag mt-2 inline-block">{recipe.category || "Uncategorized"}</span>
        <div className="flex gap-4 mt-4">
          <div className="flex items-center text-sm cooking-time">
            <Clock className="mr-1 h-4 w-4" />
            {recipe.cookingTime} mins
          </div>
          <div className="flex items-center text-sm servings">
            <Users className="mr-1 h-4 w-4" />
            Serves {recipe.servings}
          </div>
        </div>
      </div>
      <CardContent className="space-y-6 pt-6">
        <div className="bg-white p-4 rounded-lg shadow-sm">
          <h3 className="font-medium mb-2 text-recipe-spice flex items-center">
            <ChefHat className="mr-2 h-4 w-4" />
            Description
          </h3>
          <p className="text-muted-foreground">{recipe.description}</p>
        </div>

        <div className="bg-recipe-cream/50 p-4 rounded-lg shadow-sm">
          <h3 className="font-medium mb-2 text-recipe-herb flex items-center">
            <Utensils className="mr-2 h-4 w-4" />
            Ingredients
          </h3>
          <ul className="space-y-1">
            {recipe.ingredients.map((ingredient, index) => (
              <li key={index} className="ingredient-item">
                {ingredient}
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-sm">
          <h3 className="font-medium mb-4 text-recipe-spice flex items-center">
            <Clock className="mr-2 h-4 w-4" />
            Instructions
          </h3>
          <div className="instruction-list">
            {recipe.instructions.map((step, index) => (
              <div key={index} className="instruction-step">
                <p className="text-muted-foreground">{step}</p>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

