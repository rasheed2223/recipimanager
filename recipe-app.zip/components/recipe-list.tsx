"use client"

import { useState, useEffect } from "react"
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from "@dnd-kit/core"
import {
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
} from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"
import { fetchRecipes, updateRecipeOrder } from "@/lib/api"
import type { Recipe } from "@/types/recipe"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Skeleton } from "@/components/ui/skeleton"
import { Clock, Search, GripVertical, Filter } from "lucide-react"

interface RecipeListProps {
  onRecipeSelect: (recipe: Recipe) => void
}

export default function RecipeList({ onRecipeSelect }: RecipeListProps) {
  const [recipes, setRecipes] = useState<Recipe[]>([])
  const [categories, setCategories] = useState<string[]>([])
  const [selectedCategory, setSelectedCategory] = useState<string>("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [loading, setLoading] = useState(true)

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  )

  useEffect(() => {
    const loadRecipes = async () => {
      try {
        const data = await fetchRecipes()
        setRecipes(data)

        // Extract unique categories
        const uniqueCategories = Array.from(new Set(data.map((recipe) => recipe.category || "Uncategorized")))
        setCategories(["all", ...uniqueCategories])
      } catch (error) {
        console.error("Error loading recipes:", error)
      } finally {
        setLoading(false)
      }
    }

    loadRecipes()
  }, [])

  const handleDragEnd = async (event: any) => {
    const { active, over } = event

    if (active.id !== over.id) {
      const oldIndex = recipes.findIndex((recipe) => recipe.id === active.id)
      const newIndex = recipes.findIndex((recipe) => recipe.id === over.id)

      const newRecipes = [...recipes]
      const [movedRecipe] = newRecipes.splice(oldIndex, 1)
      newRecipes.splice(newIndex, 0, movedRecipe)

      setRecipes(newRecipes)

      // Update order in the backend
      try {
        await updateRecipeOrder(
          newRecipes.map((recipe, index) => ({
            id: recipe.id,
            order: index,
          })),
        )
      } catch (error) {
        console.error("Error updating recipe order:", error)
      }
    }
  }

  const filteredRecipes = recipes.filter((recipe) => {
    const matchesCategory = selectedCategory === "all" || recipe.category === selectedCategory
    const matchesSearch =
      recipe.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      recipe.description.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesCategory && matchesSearch
  })

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-6 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-20 w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="search-container">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search recipes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8 border-recipe-butter focus:border-recipe-spice"
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-recipe-herb" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="category-select"
            >
              {categories.map((category) => (
                <option key={category} value={category}>
                  {category === "all" ? "All Categories" : category}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {filteredRecipes.length === 0 ? (
        <div className="bg-white p-8 rounded-lg text-center">
          <p className="text-muted-foreground">No recipes found. Try a different search or category.</p>
        </div>
      ) : (
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
          <SortableContext items={filteredRecipes.map((recipe) => recipe.id)} strategy={verticalListSortingStrategy}>
            <div className="space-y-4">
              {filteredRecipes.map((recipe) => (
                <SortableRecipeItem key={recipe.id} recipe={recipe} onRecipeSelect={onRecipeSelect} />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      )}
    </div>
  )
}

interface SortableRecipeItemProps {
  recipe: Recipe
  onRecipeSelect: (recipe: Recipe) => void
}

function SortableRecipeItem({ recipe, onRecipeSelect }: SortableRecipeItemProps) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: recipe.id })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  }

  return (
    <div ref={setNodeRef} style={style} {...attributes}>
      <Card className="recipe-card">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>{recipe.title}</CardTitle>
              <span className="category-tag mt-1 inline-block">{recipe.category || "Uncategorized"}</span>
            </div>
            <div {...listeners} className="cursor-grab active:cursor-grabbing p-1">
              <GripVertical className="h-5 w-5 text-muted-foreground" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p className="line-clamp-2 text-sm text-muted-foreground">{recipe.description}</p>
        </CardContent>
        <CardFooter className="flex justify-between">
          <div className="flex items-center text-sm cooking-time">
            <Clock className="mr-1 h-4 w-4" />
            {recipe.cookingTime} mins
          </div>
          <Button
            variant="outline"
            className="border-recipe-herb text-recipe-herb hover:bg-recipe-herb hover:text-white"
            onClick={() => onRecipeSelect(recipe)}
          >
            View Details
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

