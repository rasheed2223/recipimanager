import type { Recipe } from "@/types/recipe"

// Mock data for development
const MOCK_RECIPES: Recipe[] = [
  {
    id: "1",
    title: "Spaghetti Carbonara",
    description: "A classic Italian pasta dish with eggs, cheese, pancetta, and black pepper.",
    category: "Italian",
    cookingTime: 25,
    servings: 4,
    ingredients: [
      "400g spaghetti",
      "200g pancetta or guanciale, diced",
      "4 large eggs",
      "100g Pecorino Romano, grated",
      "50g Parmesan, grated",
      "Freshly ground black pepper",
      "Salt",
    ],
    instructions: [
      "Bring a large pot of salted water to boil and cook the spaghetti until al dente.",
      "While the pasta is cooking, fry the pancetta in a large pan until crispy.",
      "In a bowl, whisk together the eggs, grated cheeses, and black pepper.",
      "Drain the pasta, reserving some cooking water, and add it to the pan with the pancetta.",
      "Remove the pan from heat and quickly stir in the egg mixture, adding a splash of pasta water to create a creamy sauce.",
      "Serve immediately with extra grated cheese and black pepper.",
    ],
  },
  {
    id: "2",
    title: "Chocolate Chip Cookies",
    description: "Classic homemade chocolate chip cookies that are soft, chewy, and loaded with chocolate chips.",
    category: "Dessert",
    cookingTime: 15,
    servings: 24,
    ingredients: [
      "250g all-purpose flour",
      "1/2 tsp baking soda",
      "1/2 tsp salt",
      "170g unsalted butter, melted",
      "200g brown sugar",
      "100g white sugar",
      "1 tbsp vanilla extract",
      "1 egg",
      "1 egg yolk",
      "300g chocolate chips",
    ],
    instructions: [
      "Preheat oven to 325°F (165°C). Line baking sheets with parchment paper.",
      "Sift together the flour, baking soda, and salt; set aside.",
      "In a medium bowl, cream together the melted butter, brown sugar, and white sugar until well blended.",
      "Beat in the vanilla, egg, and egg yolk until light and creamy.",
      "Mix in the sifted ingredients until just blended.",
      "Stir in the chocolate chips by hand using a wooden spoon.",
      "Drop cookie dough onto the prepared baking sheets, with each cookie about 3 tablespoons of dough.",
      "Bake for 15-17 minutes, or until the edges are lightly toasted.",
      "Cool on baking sheets for a few minutes before transferring to wire racks to cool completely.",
    ],
  },
  {
    id: "3",
    title: "Vegetable Stir Fry",
    description: "A quick and healthy vegetable stir fry with a savory sauce.",
    category: "Asian",
    cookingTime: 20,
    servings: 4,
    ingredients: [
      "2 tbsp vegetable oil",
      "2 cloves garlic, minced",
      "1 tbsp ginger, grated",
      "1 bell pepper, sliced",
      "1 carrot, julienned",
      "1 broccoli head, cut into florets",
      "1 cup snap peas",
      "1 cup mushrooms, sliced",
      "3 tbsp soy sauce",
      "1 tbsp oyster sauce",
      "1 tsp sesame oil",
      "1 tsp cornstarch mixed with 2 tbsp water",
    ],
    instructions: [
      "Heat oil in a wok or large frying pan over high heat.",
      "Add garlic and ginger, stir fry for 30 seconds until fragrant.",
      "Add vegetables, starting with the ones that take longer to cook (carrots, broccoli).",
      "Stir fry for 5-6 minutes until vegetables are crisp-tender.",
      "Add soy sauce, oyster sauce, and sesame oil, toss to combine.",
      "Pour in cornstarch slurry and stir until sauce thickens.",
      "Serve hot over rice or noodles.",
    ],
  },
]

// Simulate API calls with mock data
export async function fetchRecipes(): Promise<Recipe[]> {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 800))
  return [...MOCK_RECIPES]
}

export async function fetchRecipeById(id: string): Promise<Recipe | null> {
  await new Promise((resolve) => setTimeout(resolve, 500))
  return MOCK_RECIPES.find((recipe) => recipe.id === id) || null
}

export async function fetchRandomRecipe(): Promise<Recipe> {
  await new Promise((resolve) => setTimeout(resolve, 1000))
  const randomIndex = Math.floor(Math.random() * MOCK_RECIPES.length)
  return MOCK_RECIPES[randomIndex]
}

export async function createRecipe(recipe: Omit<Recipe, "id">): Promise<Recipe> {
  await new Promise((resolve) => setTimeout(resolve, 1200))
  const newRecipe: Recipe = {
    ...recipe,
    id: Math.random().toString(36).substring(2, 9),
  }

  // In a real app, you would send a POST request to your API
  // For now, we'll just simulate adding to our mock data
  MOCK_RECIPES.push(newRecipe)

  return newRecipe
}

export async function updateRecipe(recipe: Recipe): Promise<Recipe> {
  await new Promise((resolve) => setTimeout(resolve, 800))

  // In a real app, you would send a PUT request to your API
  const index = MOCK_RECIPES.findIndex((r) => r.id === recipe.id)
  if (index !== -1) {
    MOCK_RECIPES[index] = recipe
  }

  return recipe
}

export async function updateRecipeOrder(updates: { id: string; order: number }[]): Promise<void> {
  await new Promise((resolve) => setTimeout(resolve, 600))

  // In a real app, you would send a PATCH request to your API
  // For now, we'll just log the updates
  console.log("Recipe order updated:", updates)
}

